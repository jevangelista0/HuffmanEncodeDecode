import java.io.PrintWriter;
import java.util.Scanner;

public class HuffBinTree {
	public TreeNode root;
	public String charCode[];
	
	public HuffBinTree() {
		root = null;
		charCode = new String[256];
	}
	
	public void Encode(Scanner origF, PrintWriter compF) { // original and compressed file respective
		// index <- cast to int, getCode from charCode[index], print to compF, repeat till end of line, repeat till eof
		while(origF.hasNext()){
			String line = origF.nextLine();
			
			for(int i=0; i<line.length(); i++){
				compF.print(charCode[(int)line.charAt(i)]);
			}
			compF.print(charCode[10]);
		}
		
		origF.close();
		compF.close();
	}
	
	public void decode(Scanner encoded, PrintWriter decoded){
		TreeNode curr = root;
		
		while(encoded.hasNext()){
			String bit = encoded.next();
			
			for(int i=0; i<bit.length(); i++){
				if(curr.left == null && curr.left == curr.right){
					decoded.print(curr.ch);
					System.out.print(curr.ch);
					curr = root;
				}
				
				if(bit.charAt(i) == '0'){
					curr = curr.left;
				}else if(bit.charAt(i) == '1'){
					curr = curr.right;
				}else{
					System.out.println("Error! The compress file contains invalid character!");
				}
			}
			
		}
		System.out.println();
		
		// check if there is no more next and !isLeaf()
		if(!encoded.hasNext() && curr.left != null && curr.left == curr.right){
			System.out.println("Error:  The compress file is corrupted!");
		}
		
		encoded.close();
		decoded.close();
	}
	
	public void constructCode(TreeNode currNode, String code){
		if(currNode.left == null && currNode.left == currNode.right){
			currNode.code = code;
			int index = (int)currNode.ch.charAt(0);
//			if(index == 10)
//				System.out.println("endl " + code);
			charCode[index] = code;
		}else{
			constructCode(currNode.left, code + "0");
			constructCode(currNode.right, code + "1");
		}
	}
	
	public boolean isLeaf(TreeNode node){
		return node.left == node.right && node.left == null;
	}
	
	public void constructHuffLinkedList(Scanner scan, PrintWriter out1, PrintWriter out2, PrintWriter out3, PrintWriter out4) {
		HuffLinkedList list = new HuffLinkedList();
		
		try{
			
			while(scan.hasNext()){
				String str = scan.next();
				int num = scan.nextInt();
				
				if(num == 350){
					TreeNode nNode = new TreeNode(" ", num, "");
					list.insertOneNode(list.findSpot(nNode), nNode);
				}else if(num == 80){
					TreeNode nNode = new TreeNode(Character.toString((char)10), num, "");
					list.insertOneNode(list.findSpot(nNode), nNode);
				}else{
					TreeNode nNode = new TreeNode(str, num, "");
					list.insertOneNode(list.findSpot(nNode), nNode);
				}
					
			}
			
			constructHuffBinTree(list, out1, out2, out3, out4);
		}catch(Exception e){
			e.printStackTrace();
		}
	} // LinkedList
	
	public void constructHuffBinTree(HuffLinkedList list, PrintWriter out1, PrintWriter out2, PrintWriter out3, PrintWriter out4){
		out1.println("--PrintLL--");
		list.printLL(out1); // TODO UNCOMMENT!
		
		while(list.ListHead.next.next != null){
			TreeNode nNode = new TreeNode("", 0, ""); // init new node
			
			nNode.ch = list.ListHead.next.ch + list.ListHead.next.next.ch;
			nNode.prob = list.ListHead.next.prob + list.ListHead.next.next.prob;
			nNode.left = list.ListHead.next;
			nNode.right = list.ListHead.next.next;
			
			list.ListHead.next = list.ListHead.next.next.next;
			
			list.insertOneNode(list.findSpot(nNode), nNode);
			list.printLL(out1); // TODO: UNCOMMENT!
		}
		root = list.ListHead.next;
		out2.println("---pre---");
		out2.println(" ch prob nextChar leftChar rightChar\n");
		preOrderTraversal(root, out2);
		
		out3.println("---in---");
		out3.println(" ch prob nextChar leftChar rightChar\n");
		inOrderTraversal(root, out3);
		
		out4.println("---post---");
		out4.println(" ch prob nextChar leftChar rightChar\n");
		postOrderTraversal(root, out4);
	} // BinTree //		System.out.println("ch prob code next left right");
	
	public void preOrderTraversal(TreeNode curr, PrintWriter out){ // print before (print current node, L to R) TODO: add outfile
		if(curr == null){
			return;
		}else{
			curr.printNode(out);
			preOrderTraversal(curr.left, out);
			preOrderTraversal(curr.right, out);
		}
	}
	
	public void inOrderTraversal(TreeNode curr, PrintWriter out){ // print in the middle (finish subtree first, L to R)
		if(curr == null){
			return;
		}else{
			inOrderTraversal(curr.left, out);
			curr.printNode(out);
			inOrderTraversal(curr.right, out);
		}
	}
	
	public void postOrderTraversal(TreeNode curr, PrintWriter out){ // print after (finish lower level first)
		if(curr == null){
			return;
		}else{
			postOrderTraversal(curr.left, out);
			postOrderTraversal(curr.right, out);
			curr.printNode(out);
		}
	}
	
}
