import java.io.PrintWriter;

public class TreeNode {
	
	public int prob;
	public String ch;
	public String code;
	public TreeNode next;
	public TreeNode left;
	public TreeNode right;
	
	public TreeNode(String ch, int prob, String code) {
		this.prob = prob;
		this.ch = ch; // Str
		this.code = code; // Str
		this.next = null;
		this.left = null;
		this.right = null;
	}
	
	public void printNode(PrintWriter out){	
		out.print(ch + " " + prob + " " + code);
		
		if(next == null){
			out.print(" NULL ");
		}else{
			out.print(" " + next.ch);
		}
		
		if(left == null){
			out.print(" NULL ");
		}else{
			out.print(" " + left.ch);
		}
		
		if(right == null){
			out.println(" NULL ");
		}else{
			out.println(" " + right.ch);
		}
	}
}
// list.insertOneNode(list.findSpot(new TreeNode("e", 99, "")), new TreeNode("e", 99, ""));
// System.out.println("---Print Node---\nch prob code next left right");