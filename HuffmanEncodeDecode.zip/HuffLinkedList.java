import java.io.PrintWriter;

public class HuffLinkedList {
	public TreeNode ListHead;
	
	public HuffLinkedList() {
		ListHead = new TreeNode("dummy", 0, "");
	}
	
	public void insertOneNode(TreeNode spot, TreeNode nNode){
		nNode.next = spot.next;
		spot.next = nNode;
		
	}
	
	public TreeNode findSpot(TreeNode nNode){
		TreeNode spot = ListHead;
		
		while(spot.next != null){			
			if(nNode.prob <= spot.next.prob) // <= to reduce time traversal mfgdwkhp mdwgfkhp
				break;
				
			
			spot = spot.next;
		}
		
		return spot;
	}
	
	public void printLL(PrintWriter out){
		out.println("https://github.com/jevangelista0");
		
		if(ListHead.next == null){
			out.println("Empty");
		}else{
			TreeNode spot = ListHead;
			
			out.print("ListHead->(" + spot.ch + ", " + spot.prob + ", " + spot.next.ch + ")");
			while(spot.next != null){
				spot = spot.next;
				
				if(spot.next == null)
					out.print("->(" + spot.ch + ", " + spot.prob + ", NULL)->NULL\n");
				else
					out.print("->(" + spot.ch + ", " + spot.prob + ", " + spot.next.ch + ")");
			}
		}
	}
	
}