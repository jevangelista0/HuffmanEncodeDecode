import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Scanner;

public class HuffmanEncodeDecode {
	
	public static void main(String[] args) {
		HuffBinTree binTree = new HuffBinTree();
		// first half
		try{
			Scanner in = new Scanner(new FileReader(args[0]));
			PrintWriter out1 = new PrintWriter(args[1]);
			PrintWriter out2 = new PrintWriter(args[2]);
			PrintWriter out3 = new PrintWriter(args[3]);
			PrintWriter out4 = new PrintWriter(args[4]);
			
			binTree.constructHuffLinkedList(in, out1, out2, out3, out4);
			binTree.constructCode(binTree.root, "");
			
			in.close();
			out1.close();
			out2.close();
			out3.close();
			out4.close();
		}catch(Exception e){
			System.out.println(e);
		}		
		
		// second half
		char yOrN;
		
		Scanner decision = new Scanner(System.in);
		System.out.print("�Y� for yes, �N� for no: ");
		yOrN = decision.next().charAt(0);
		
		try{
		
			while(Character.toLowerCase(yOrN) == 'y'){
				String orgName = "";			
				System.out.print("Please input the filename (name only extension .txt will be added): ");
				orgName = decision.next(); // get actual name
				String compressedName = orgName + "_Compressed.txt";
				String decompressedName = orgName + "_Decompressed.txt";
				orgName += ".txt"; // add the extension for orgName
				// DONE W INIT PROCESS
				
				// open inputfile and compress and decompress of it
				Scanner origF = new Scanner(new FileReader(orgName));
				PrintWriter compF = new PrintWriter(compressedName);
				PrintWriter decompF = new PrintWriter(decompressedName);
				
				binTree.Encode(origF, compF);
				compF.close();
				decompF.close();
				
				Scanner encoded = new Scanner(new FileReader(compressedName));
				PrintWriter decoded = new PrintWriter(decompressedName);
				binTree.decode(encoded, decoded);
				
				// Loop??? Y or N?
				System.out.print("�Y� for yes, �N� for no: ");
				yOrN = decision.next().charAt(0);
			}
			decision.close();
		}catch(Exception e){
			System.out.println(e);
		}
		
	}
}
